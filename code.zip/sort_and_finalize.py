#script to compute totals and sort 

import pandas as pd

df = pd.read_csv("marks.csv")
df["Total"] = df[["Maths", "Physics", "Chemistry"]].sum(axis=1)
df = df.sort_values(by="Total", ascending=False)
df.to_csv("final_results.csv", index=False)
print("Final results generated and sorted by total marks.")
