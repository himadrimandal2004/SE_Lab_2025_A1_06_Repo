# For students to view results

import pandas as pd


df = pd.read_csv("final_result.csv")
print(df[["Roll No", "Name", "Maths", "Physics", "Chemistry", "Total"]])
