# Script for teachers to update marks

import pandas as pd
import sys
import json
import os

def update_marks(teacher, roll_no, new_mark):
    # Check if config file exists
    if not os.path.exists("teacher_config.json"):
        print("Error: 'teacher_config.json' file not found.")
        return

    # Load teacher config safely
    try:
        with open("teacher_config.json") as f:
            config = json.load(f)
    except json.JSONDecodeError:
        print("Error: 'teacher_config.json' is not a valid JSON file.")
        return

    # Check if teacher is authorized
    if teacher not in config:
        print(f"Unauthorized teacher: {teacher}")
        return

    subject = config[teacher]

    # Check if marks.csv exists
    if not os.path.exists("marks.csv"):
        print("Error: 'marks.csv' file not found.")
        return

    try:
        df = pd.read_csv("marks.csv")
        df.columns = df.columns.str.strip()  # Clean up column names
    except Exception as e:
        print(f"Error reading 'marks.csv': {e}")
        return

    # Check if required columns exist
    if "Roll No" not in df.columns:
        print("Error: 'Roll No' column not found in 'marks.csv'")
        print("Columns available:", df.columns.tolist())
        return

    if subject not in df.columns:
        print(f"Error: Subject column '{subject}' not found in 'marks.csv'")
        print("Columns available:", df.columns.tolist())
        return

    # Check if roll number exists
    if roll_no not in df["Roll No"].values:
        print(f"Roll number {roll_no} not found.")
        return

    # Update the mark
    df.loc[df["Roll No"] == roll_no, subject] = new_mark
    df.to_csv("marks.csv", index=False)
    print(f"{subject} marks updated for Roll No {roll_no}.")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python update_marks.py <teacher> <roll_no> <new_mark>")
    else:
        try:
            update_marks(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]))
        except ValueError:
            print("Error: roll_no and new_mark must be integers.")

